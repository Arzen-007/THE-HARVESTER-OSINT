# theHarvester OSINT GUI - Setup Guide

## Overview
A world-class hacker-vibe web GUI for theHarvester OSINT tool. Built with React + tRPC + FastAPI + TheHarvester.

## Features
- Matrix Rain animated background
- Terminal-style output panel
- 60+ OSINT sources selection
- DNS Brute Force support
- Real-time scan monitoring
- Results export (JSON)
- Scan history tracking
- Cyberpunk/hacker aesthetic UI

## Prerequisites
- Linux OS
- Python 3.12+
- Node.js 20+
- MySQL Database

## Step 1: Install TheHarvester

```bash
# Clone theHarvester
cd ~
git clone https://github.com/laramies/theHarvester.git
cd theHarvester

# Install dependencies
pip install netaddr dnspython certifi beautifulsoup4 lxml PyYAML ujson \
  aiohttp aiodns aiofiles aiomultiprocess aiosqlite httpx shodan uvicorn \
  fastapi slowapi python-dateutil retrying aiohttp-socks playwright censys
```

## Step 2: Setup the GUI Project

```bash
# Copy project files
cp -r /path/to/gui/project ~/theharvester-gui
cd ~/theharvester-gui

# Install dependencies
npm install

# Setup database
npm run db:push
```

## Step 3: Configure Environment

Edit `.env` file:
```env
DATABASE_URL=mysql://user:password@localhost:3306/harvester_db
```

## Step 4: Start the Application

```bash
# Development mode
npm run dev

# Production mode
npm run build
npm start
```

The app will be available at `http://localhost:3000`

## How to Use

1. Enter target domain (e.g., `example.com`)
2. Select OSINT sources (or "Select All")
3. Set result limit (default: 500)
4. Click "INITIATE OSINT SCAN"
5. Watch terminal output for progress
6. View results in the Results tab
7. Export results as JSON

## API Endpoints

The backend exposes these tRPC procedures:
- `harvester.sources` - Get available OSINT sources
- `harvester.scan` - Start a new scan
- `harvester.scanHistory` - Get scan history
- `harvester.getScanResults` - Get results by scan ID
- `harvester.dnsBrute` - DNS brute force

## Tech Stack

**Frontend:**
- React 19 + TypeScript
- Tailwind CSS
- shadcn/ui components
- tRPC client

**Backend:**
- Hono + tRPC
- Drizzle ORM + MySQL
- TheHarvester FastAPI integration

**OSINT Engine:**
- theHarvester (60+ sources)
- FastAPI REST API

## License

For authorized security testing only. Use responsibly.
